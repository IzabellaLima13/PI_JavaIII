package br.com.veiculo.carro;

public enum Cores {
	
	BRANCO, PRATA, PRETO, VERMELHO, ROSA, AZUL, VINHO, VERDE;

}
