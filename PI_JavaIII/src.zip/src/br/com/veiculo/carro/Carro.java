package br.com.veiculo.carro;

import br.com.veiculo.Veiculo;

public class Carro extends Veiculo {
	
	public Carro(String chassi, String montadora, String modelo, float motorizacao, float preco) {
		super(chassi, montadora, modelo, motorizacao, preco);
	}
}
