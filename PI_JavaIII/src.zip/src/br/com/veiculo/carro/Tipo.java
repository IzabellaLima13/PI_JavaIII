package br.com.veiculo.carro;

public enum Tipo {
	
	SEDAN, HATCH, ESPORTIVO, CONVERSIVEL, UTILIT�RIO, PICAPE;

}
