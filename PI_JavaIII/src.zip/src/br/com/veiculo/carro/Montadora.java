package br.com.veiculo.carro;

public enum Montadora {
	
	HONDA, FIAT, RENAULT, PEUGEOT, FORD, VOLKSWAGEN;

}
