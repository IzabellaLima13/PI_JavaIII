package br.com.veiculo.carro;

public enum Cambio {	
	AUTOM�TICO, SEMI_AUTOM�TICO, MANUAL;
}
