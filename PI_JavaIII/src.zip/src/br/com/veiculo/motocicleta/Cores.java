package br.com.veiculo.motocicleta;

public enum Cores {

	PRETO, AMARELO, OURO, AZUL, PRATA, VERMELHO, BRANCO;
}
