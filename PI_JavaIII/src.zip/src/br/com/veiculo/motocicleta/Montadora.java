package br.com.veiculo.motocicleta;

public enum Montadora {
	
	YAMAHA, HARLEY, SHADON,KASINSKI,HONDA, SUZUKI;

}
